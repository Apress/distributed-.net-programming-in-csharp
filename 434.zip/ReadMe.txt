Hello!

Thanks for purchasing "Distributed .NET Programming in C#". This zip
file contains source code for many of the examples given in the book.
I have just a few notes regarding this example code:

* All code has been developed using Visual Studio .NET and the final
  release of .NET. In most cases, you can simply open the .sln file
  and go!

* Some projects may require that you reset references to external 
  assemblies.

* The example code for Chapter 6 (Web Services) and Chapter 8 
  (Component Services) will require additional steps to run. Please
  see the text of the book for details.

If you have any problems, questions, or suggestions regarding the 
book or example code, feel free to email me at tbarnaby@intertech-inc.com. 
I will do my best to answer questions in a timely fashion.

Thanks again, and good luck!
Tom Barnaby

