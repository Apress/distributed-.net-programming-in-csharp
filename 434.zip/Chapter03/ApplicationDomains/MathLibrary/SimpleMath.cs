using System;

// In SimpleMath.cs
namespace MathLibrary
{
   public class SimpleMath
   {
      public static int Add(int n1, int n2)
      {
         return n1 + n2;
      }

      public static int Subtract(int n1, int n2)
      {
         return n1 - n2;
      }
   }
}


